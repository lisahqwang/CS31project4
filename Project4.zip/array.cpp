//Name: Lisa Wang 
//UID: 105502901
//Project 4, Professor Huang CS 31 

#include <iostream>
#include <string>
#include <assert.h> //for testing in the main function
using namespace std;
//function declarations

int locateMaximum(const string array[], int n);
int countFloatingPointValues(const string array[], int  n);
int shiftLeft(string array[], int n, int amount, string placeholder);
int replaceFirstAndLastOccurrences(string array[], int n, char charToFind, char charToReplace);
bool identicalValuesTogether(const string array[], int n);
bool hasTwoOrMoreDuplicates(const string array[], int  n);
bool hasNoCapitals(const string array[], int n);

//main function
int main() {
    string a[6] = { "123", "456", "789", "gamma", "beta", "delta" };

    assert(hasNoCapitals(a, 6) == true);
    assert(countFloatingPointValues(a, 3) == 3);

    return(0);
}

int locateMaximum(const string array[], int n) {
    string temp = array[0]; //initializing and declaring a temp string to be used for future comparison purposes
    int index = 0; //initializing and declaring an index, for counting purposes and will be returned
    for (int i = 0; i < n - 1; i++) { //first layer of a for loop, traversing through the array string 
        int s1 = array[i].length();  //getting array's length 
        int s2 = array[i + 1].length(); // for comparison
        int sz;
        sz = (s1 <= s2) ? s1 : s2;
        for (int k = 0; k < sz; k++) {
            if (array[i][k] < array[i + 1][k]) {
                temp = array[i + 1];
                index = i + 1;
            }
        }
        if (s2 > sz) { //comparing the values of the second string and the newly established sz 
            temp = array[i + 1];
            index = i + 1;
        }
    }
    if (index < 0 || n <= 0) { //condition stated
        return -1;
    }
    return index; // to avoid off by one issues
}

int countFloatingPointValues(const string array[], int  n) {
    if (n <= 0) {
        return -1; //condition stated
    }
    int total = n; //counting for total numbers of floating point values
    int flag = 0; //notifying if there is a flagged valued
    for (int i = 0; i < n; i++) {
        int sz = array[i].length();
        if (sz == 0) {
            total--;
            continue;
        }
        flag = 0;  // starting with no flags
        for (int j = 0; j < sz; j++)  //entering second for loop, for each string 
        {
            if ((array[i][j] > '9') || (array[i][j] < '0')) { //if not numbers
                if (array[i][j] == '.') flag = 0;  //if pointed to a dot, then no flag
                else {
                    flag = 1; //if not anything above indicated, raise a flag
                    break;
                }
            }

        }
        if (flag == 1) {
            total--;
        }

    }
    if (total < 0 || n == 0) {  //this can not be true for this checking purpose
        return -1;
    }
    else {
        return total;
    }
}

bool hasNoCapitals(const string array[], int n) {
    if (n <= 0) {
        return true;
    }
    for (int i = 0; i < n; i++) {
        int sz = array[i].length();// get the size of the second for loop
        for (int j = 0; j < sz; j++) //enter the second for loop
        {
            if (isupper(array[i][j])) { //using the cctype function isupper to check for the chars 
                return false;
            }
        }
    }
    return true;
}

bool identicalValuesTogether(const string array[], int n)
{
    string temp = array[0];
    if (n <= 0) {
        return false;  // boundary condition checking 
    }
    for (int i = 0; i < n; i++) { //enter first for loop
        for (int j = i + 1; j < n; j++)  //enter second for loop 
        {
            temp = array[i + 1]; //setting a checking variable for each next item in the array
            if (array[i] == array[j] && array[j] != temp) {
                return false; //if the pointed item is not equal to temp, then it is not the consequtively next to the pointed item
            }
            else {
                continue;
            }
        }
    }
    return true;

}

bool hasTwoOrMoreDuplicates(const string array[], int  n) {
    if (n <= 0) { //checking for basic conditions
        return false;
    }
    int counter = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) { //using double for loops to check for equvilence
            if (array[i] == array[j]) {
                counter++;
            }
        }
    }
    if (counter >= 2) {  //if occurs more than or equal to twice
        return true;
    }
    else {
        return false;
    }
}

int shiftLeft(string array[], int n, int amount, string placeholder) {
    if (amount < 0 || n <= 0) {  //checking for basic condition
        return -1;
    }
    if (amount >= n) { // if the amount shifted is going to be greater than n,
        //you know it will have the whole array to set to placeholder
        for (int i = 0; i < n; i++) {
            array[i] = placeholder;
        }
        return n;
    }

    for (int i = 0; i < amount; i++) {
        array[i] = array[i + amount]; //for loop, setting each time shifted to be minus the place it was already
    }
    return amount;
}


int replaceFirstAndLastOccurrences(string array[], int n, char charToFind, char charToReplace) {
    int counter = 0;
    if (n <= 0) {
        return -1; //checking basic condition
    }
    for (int i = 0; i < n; i++) {
        int sz = array[i].length();
        if (charToFind == array[i][0]) {
            array[i][0] = charToReplace;
            counter++;// no second for-loop,
        }
        if (charToFind == array[i][sz - 1]) {
            array[i][sz - 1] = charToReplace; // replacing each char with the char indicated in the parameter 
            counter++; //counting the number of exchanges 
        }
    }
    return counter; //return the number of exchanges. 
}